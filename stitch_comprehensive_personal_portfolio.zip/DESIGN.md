---
name: Tenebrous Cream
colors:
  surface: '#fff8f6'
  surface-dim: '#e9d6d1'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ec'
  surface-container: '#fdeae4'
  surface-container-high: '#f7e4de'
  surface-container-highest: '#f2dfd9'
  on-surface: '#231916'
  on-surface-variant: '#4f4441'
  inverse-surface: '#392e2a'
  inverse-on-surface: '#ffede8'
  outline: '#817470'
  outline-variant: '#d3c3be'
  surface-tint: '#725950'
  primary: '#110402'
  on-primary: '#ffffff'
  primary-container: '#2d1b14'
  on-primary-container: '#9d8177'
  inverse-primary: '#e0c0b4'
  secondary: '#5e5e5b'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdb'
  on-secondary-container: '#63635f'
  tertiary: '#0f0502'
  on-tertiary: '#ffffff'
  tertiary-container: '#2b1c15'
  on-tertiary-container: '#998278'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#fddbd0'
  primary-fixed-dim: '#e0c0b4'
  on-primary-fixed: '#291710'
  on-primary-fixed-variant: '#584239'
  secondary-fixed: '#e4e2dd'
  secondary-fixed-dim: '#c8c6c2'
  on-secondary-fixed: '#1b1c19'
  on-secondary-fixed-variant: '#474744'
  tertiary-fixed: '#f9ddd1'
  tertiary-fixed-dim: '#dbc1b5'
  on-tertiary-fixed: '#271811'
  on-tertiary-fixed-variant: '#55433a'
  background: '#fff8f6'
  on-background: '#231916'
  surface-variant: '#f2dfd9'
typography:
  display-lg:
    fontFamily: ebGaramond
    fontSize: 64px
    fontWeight: '500'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: ebGaramond
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: ebGaramond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: ebGaramond
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  body-lg:
    fontFamily: hankenGrotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: hankenGrotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: hankenGrotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style
The design system embodies an editorial, high-end aesthetic that blends **Minimalism** with **Tactile** sophistication. It is tailored for luxury e-commerce, high-end publishing, or artisanal portfolio sites where the objective is to evoke a sense of quiet confidence, heritage, and meticulous craft.

The brand personality is authoritative yet welcoming, utilizing a "warm-minimalist" approach. The interface relies on expansive white space (using a rich cream base) and deep, chocolate-toned typography to create a rhythmic, breathable reading experience. Visual interest is generated through precise typographic hierarchies and subtle tonal layering rather than excessive decoration.

## Colors
The palette is centered on a high-contrast relationship between deep, dark roasted tones and a soft, organic off-white.

- **Primary (Espresso):** A near-black brown used for primary actions, headings, and high-impact UI elements. It provides the "ink" of the design system.
- **Secondary (Cream):** The primary surface color. It reduces eye strain compared to pure white and adds a premium, paper-like quality.
- **Tertiary (Muted Bark):** A mid-tone used for secondary text, borders, and disabled states.
- **Neutral (Obsidian Brown):** Reserved for absolute darkest accents, such as deep shadows or heavy borders, ensuring the Espresso doesn't feel washed out.

Maintain a strict adherence to these tones. Avoid pure blacks (#000) or pure whites (#FFF) to preserve the sophisticated, organic character of the system.

## Typography
The typographic system pairs a classical serif with a precision-engineered sans-serif.

- **Headlines:** Use **EB Garamond** for all display and heading roles. It should be set with tight tracking in larger sizes to emphasize its elegant, calligraphic roots.
- **Body & UI:** Use **Hanken Grotesk** for readability and a contemporary edge. The generous x-height ensures clarity against the cream background.
- **Hierarchy:** Use the `label-md` style (uppercase with tracking) for navigation and small categories to provide a clear architectural anchor for the page.

## Layout & Spacing
The system utilizes a **Fixed Grid** philosophy for desktop to maintain editorial control over line lengths and image placement.

- **Grid:** 12-column grid with a 24px gutter.
- **Rhythm:** All vertical spacing must be a multiple of 8px. Use generous margins (64px+) between sections to allow the Espresso-on-Cream contrast to breathe.
- **Mobile:** Transition to a 4-column fluid grid with 16px side margins. Typography scales down slightly, but maintains the same line-height ratios to preserve readability.

## Elevation & Depth
In keeping with the minimalist aesthetic, depth is primarily communicated through **Tonal Layers** rather than heavy shadows.

- **Surface Levels:** The base layer is `Secondary (Cream)`. Secondary containers (like cards or sidebars) should use a slightly darker tint of the cream or a very thin 1px border in `Tertiary (Muted Bark)`.
- **Shadows:** When necessary for interactive elements (modals, dropdowns), use "Ambient Shadows"—diffused, low-opacity (#2D1B14 at 8% opacity) with a large blur radius (30px+) and no spread. This simulates a soft object resting on a matte surface.
- **Interactions:** Hover states should involve subtle shifts in background tone (e.g., Cream to a slightly more saturated beige) rather than lifting the element via shadows.

## Shapes
The shape language is **Rounded**, providing a soft, humanistic counterpoint to the sharp, dark typography. 

Standard components (buttons, inputs) utilize a 0.5rem (8px) radius. Larger containers or feature cards should scale up to 1rem (16px) or 1.5rem (24px) to emphasize their role as structural anchors. This roundedness level ensures the interface feels modern and approachable without becoming "bubbly" or juvenile.

## Components
- **Buttons:** Primary buttons are solid `Primary (Espresso)` with `Secondary (Cream)` text. They should feel heavy and grounded. Secondary buttons use a 1px `Primary` border with `Primary` text.
- **Input Fields:** Use a subtle background fill (slightly darker than the base Cream) with a bottom-border only or a very light 1px stroke. Labels should always be visible in `label-md` style.
- **Chips:** Small, rounded pill shapes using `Tertiary (Muted Bark)` at 10% opacity for the background and solid `Primary (Espresso)` for the text.
- **Cards:** Defined by their whitespace and 1px `Tertiary` border. Images within cards should have a subtle 0.5rem corner radius to match the UI.
- **Lists:** Use `Primary (Espresso)` for list markers or custom thin-stroke icons. Horizontal separators should be 1px `Tertiary` with 20% opacity.